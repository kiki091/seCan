<?php

Route::group(['middleware' => ['web']], function() {
	Route::get('/', 'Front\HomeController@index')->name('frontHome');
});
