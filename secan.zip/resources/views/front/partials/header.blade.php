<!-- navbar-->
<header class="header">
    <nav class="navbar navbar-expand-lg">
        <div class="container"><a class="navbar-brand" href="#"><img id="logo-images" class="logo" src="{{ asset('images/logo.png') }}"></a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
            aria-label="Toggle navigation"><i class="fas fa-bars"></i></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                        <div class="form-search-icon-m">
                        <input type="text" class="form-search" placeholder="Cari" />
                            <img src="{{ asset('images/search_icon.png') }}" />
                        </div>
                    </li>
                    <li class="nav-item"><a class="nav-link link-scroll" href="#hero">Beranda </a></li>
                    <li class="nav-item"><a class="nav-link link-scroll" href="#about">Tentang SeCan</a></li>
                    <li class="nav-item"><a class="nav-link link-scroll" href="#expertise">Artikel</a></li>
                    <li class="nav-item"><a class="nav-link link-scroll" href="#education">Dokter</a></li>
                    <li class="nav-item"><a class="nav-link link-scroll" href="#experience">Video</a></li>
                    <li class="nav-item"><a class="nav-link link-scroll" href="#contact">Kontak<span
                        class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <div class="form-search-icon">
                        <input type="text" class="form-search" placeholder="Cari" />
                            <img src="{{ asset('images/search_icon.png') }}" />
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>