<!-- Footer-->
<footer>
    <div class="container text-center section-padding-y">
        <div class="row px-4">
            <div class="col-lg-4 mx-auto">
                <img src="<?php echo e(asset('images/Logo.png')); ?>" style="width: auto;">
            </div>
            <div class="col-lg-4 mx-auto">
                <h6 class="text-uppercase mb-4">Kontak </h6>
                <ul class="address">
                    <li class="mb-3"><i class="fas fa-home mr-4"> </i>Green Sedayu Biz Park DM 16 No.36 <br /> Jl. Daan
                    Mogot
                    Km 18, Kalideres Jakarta Barat</li>
                    <li class="mb-3"><i class="fas fa-phone mr-4"> </i>021-22527412, 021-528429</li>
                    <li class="mb-3"><i class="fas fa-mail-bulk mr-4"> </i>hrd_recruitment@maztafarma.co.id <br />
                    marketing@maztafarma.co.id</li>
                </ul>
            </div>
            <div class="col-lg-4 mx-auto">
                <h6 class="text-uppercase mb-4">Instagram </h6>
                <div class="row">

                    <div class="col-lg-4 mt-2 col-md-6">
                        <img src="<?php echo e(asset('images/Image 01.png')); ?>" class="produk-img">
                    </div>
                    <div class="col-lg-4 mt-2 col-md-6">
                        <img src="<?php echo e(asset('images/Image 02.png')); ?>" class="produk-img">
                    </div>
                    <div class="col-lg-4 mt-2 col-md-6">
                        <img src="<?php echo e(asset('images/Image 03.png')); ?>" class="produk-img">
                    </div>
                    <div class="col-lg-4 mt-2 col-md-6">
                        <img src="<?php echo e(asset('images/Image 04.png')); ?>" class="produk-img">
                    </div>
                    <div class="col-lg-4 mt-2 col-md-6">
                        <img src="<?php echo e(asset('images/Image 05.png')); ?>" class="produk-img">
                    </div>
                    <div class="col-lg-4 mt-2 col-md-6">
                        <img src="<?php echo e(asset('images/Image 06.png')); ?>" class="produk-img">
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="copyrights px-4">
        <div class="container py-4 border-top text-center">
            <p class="mb-0 text-muted py-2">Copyright &copy; 2020 Mazta Farma All rights reserved.</p>
        </div>
    </div>
</footer><?php /**PATH /var/www/html/maztaFarma/resources/views/front/partials/footer.blade.php ENDPATH**/ ?>