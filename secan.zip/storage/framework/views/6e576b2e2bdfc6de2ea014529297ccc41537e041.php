<?php $__env->startSection('body-class',''); ?>
<?php $__env->startSection('content'); ?>

    <!-- Hero Section-->
    <section class="hero bg-cover bg-center" id="hero" class="parallax-window" data-parallax="scroll" data-image-src="<?php echo e(asset('images/bg.png')); ?>">
        <div class="medsos-info">
            <ul>
                <li>
                <i class="fab fa-facebook-f"></i>
                </li>
                <li>
                <i class="fab fa-instagram"></i>
                </li>
            </ul>

        </div>
        <div class="section-banner py-5 my-5 index-forward">
            <div class="row">
                <div class="col-md-4">
                <h2 class="h4 text-chocolate font-weight-normal mb-0">Kami Farmasi Indonesia</h2>
                <h1 class="text-uppercase text-xl mb-0">Selamat Datang</h1>
                <p class="text-shadow">Kami adalah perusahaan yang melakukan bisnis internasional dengan fokus kepada industri
                    kesehatan
                    dan kecantikan untuk memenuhi kebutuhan anda</p>
                <a href="#" class="learn-more bg-chocolate text-white">LEBIH LANJUT</a>
                </div>
            </div>
        </div>
    </section>
    <!-- About Section-->
    <section class="services text-center bg-cover bg-center" class="parallax-window" data-parallax="scroll" data-image-src="<?php echo e(asset('images/bg-section-2.png')); ?>" id="about">
        <div class="container">
            <header class="mb-5">
                <p class="font-weight-bold text-uppercase letter-spacing-3 text-chocolate">Top Services</p>
                <h2 class="h3 text-white">Unit Bisnis</h2>
            </header>
            <div class="row">
                <div class="top-40 col-lg-3 col-md-6 mb-4 mb-lg-0">
                <div class="px-4 py-5 text-center contact-item shadow-sm">
                    <img class="contact-item-thumb-img" src="<?php echo e(asset('images/service-thumbnail-1.png')); ?>">
                    <p class="text-small mb-0 text-info-services">Mazta Farma</p>
                    <img class="contact-item-img" src="<?php echo e(asset('images/service-logo-1.png')); ?>">
                </div>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-lg-0">
                <div class="px-4 py-5 text-center contact-item shadow-sm">
                    <img class="contact-item-thumb-img" src="<?php echo e(asset('images/service-thumbnail-2.png')); ?>">
                    <p class="text-small mb-0 text-info-services">Mazta Cosmetic Industry</p>
                    <img class="contact-item-img" src="<?php echo e(asset('images/service-logo-2.png')); ?>">
                </div>
                </div>

                <div class="top-40 col-lg-3 col-md-6 mb-4 mb-lg-0">
                <div class="px-4 py-5 text-center contact-item shadow-sm">
                    <img class="contact-item-thumb-img" src="<?php echo e(asset('images/service-thumbnail-3.png')); ?>">
                    <p class="text-small mb-0 text-info-services">Mazta Logistics</p>
                    <img class="contact-item-img" src="<?php echo e(asset('images/service-logo-3.png')); ?>">
                </div>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-lg-0">
                <div class="px-4 py-5 text-center contact-item shadow-sm">
                    <img class="contact-item-thumb-img" src="<?php echo e(asset('images/service-thumbnail-4.png')); ?>">
                    <p class="text-small mb-0 text-info-services">Mazta Agro Business</p>
                    <img class="contact-item-img" src="<?php echo e(asset('images/service-logo-4.png')); ?>">
                </div>
                </div>

            </div>
        </div>
    </section>
    <!-- Expertise Section        -->
    <section id="expertise">
        <div class="container">
            <div class="row">
                <div class="col-md-6 mb-5">
                <img src="<?php echo e(asset('images/thumbnail-ebook.jpg')); ?>" class="thumb-ebook">
                </div>
                <div class="col-md-6 mb-5">
                <p class="font-weight-bold text-uppercase letter-spacing-3 text-chocolate">Tentang Mazta</p>
                <h3 class="h4">Produk Mazta Farma <br />dalam eBook</h3>
                <p class="text-muted text-small">
                    Kami memiliki lebih dari 2.000 mitra dokter dan klink kecantikan di seluruh daerah di Indonesia, dengan
                    lebih dari 10 mitra pemilik brand dan produk kecantikan
                    dan obat-obatan, serta didukung oleh 5 pabrik produksi yang higenis dan berteknologi tinggi. Bagi kami
                    penting untuk tetap memberikan yang terbaik untuk
                    masyarakat Indonesia. Produk dari Mazta terpercaya dan terjamin baik.
                </p>
                <button class="btn btn-lg btn-secondary" type="button">Download our product in eBook</button>
                </div>
            </div>
        </div>
    </section>
    <!-- Education Section-->
    <section class="bg-cover bg-center text-center parallax-window" data-parallax="scroll"
        data-image-src="<?php echo e(asset('images/Background produk.png')); ?>" id="education">
        <div class="container">
            <header class="mb-5">
                <p class="font-weight-bold text-uppercase letter-spacing-3 text-chocolate">Proyeksi Kami</p>
                <h2 class="h3 text-white">Solusi Produk</h2>
            </header>
            <div class="row">
                <div class="col-lg-4 col-md-6 mt-4 mb-4 mb-lg-0">
                <img class="produk-img" src="<?php echo e(asset('images/produk-1.png')); ?>">
                </div>

                <div class="col-lg-4 col-md-6 mt-4 mb-4 mb-lg-0">
                <img class="produk-img" src="<?php echo e(asset('images/produk-2.png')); ?>">
                </div>

                <div class="col-lg-4 col-md-6 mt-4 mb-4 mb-lg-0">
                <img class="produk-img" src="<?php echo e(asset('images/produk-3.png')); ?>">
                </div>

                <div class="col-lg-4 col-md-6 mt-4 mb-4 mb-lg-0">
                <img class="produk-img" src="<?php echo e(asset('images/produk-4.png')); ?>">
                </div>

                <div class="col-lg-4 col-md-6 mt-4 mb-4 mb-lg-0">
                <img class="produk-img" src="<?php echo e(asset('images/produk-5.png')); ?>">
                </div>

                <div class="col-lg-4 col-md-6 mt-4 mb-4 mb-lg-0">
                <img class="produk-img" src="<?php echo e(asset('images/produk-6.png')); ?>">
                </div>
            </div>

        </div>
    </section>
    <!-- Experience Section        -->

    <div class="row">

        <div class="col-lg-2 pl-0 pr-0 col-md-6">
            <img src="<?php echo e(asset('images/Image 01.png')); ?>" class="produk-img">
        </div>

        <div class="col-lg-2 pl-0 pr-0 col-md-6">
            <img src="<?php echo e(asset('images/Image 02.png')); ?>" class="produk-img">
        </div>

        <div class="col-lg-2 pl-0 pr-0 col-md-6">
            <img src="<?php echo e(asset('images/Image 03.png')); ?>" class="produk-img">
        </div>

        <div class="col-lg-2 pl-0 pr-0 col-md-6">
            <img src="<?php echo e(asset('images/Image 04.png')); ?>" class="produk-img">
        </div>

        <div class="col-lg-2 pl-0 pr-0 col-md-6">
            <img src="<?php echo e(asset('images/Image 05.png')); ?>" class="produk-img">
        </div>

        <div class="col-lg-2 pl-0 pr-0 col-md-6">
            <img src="<?php echo e(asset('images/Image 06.png')); ?>" class="produk-img">
        </div>

        <div class="col-lg-2 pl-0 pr-0 col-md-6">
            <img src="<?php echo e(asset('images/Image 07.png')); ?>" class="produk-img">
        </div>

        <div class="col-lg-2 pl-0 pr-0 col-md-6">
            <img src="<?php echo e(asset('images/Image 08.png')); ?>" class="produk-img">
        </div>

        <div class="col-lg-2 pl-0 pr-0 col-md-6">
            <img src="<?php echo e(asset('images/Image 01.png')); ?>" class="produk-img">
        </div>

        <div class="col-lg-2 pl-0 pr-0 col-md-6">
            <img src="<?php echo e(asset('images/Image 02.png')); ?>" class="produk-img">
        </div>

        <div class="col-lg-2 pl-0 pr-0 col-md-6">
            <img src="<?php echo e(asset('images/Image 03.png')); ?>" class="produk-img">
        </div>

        <div class="col-lg-2 pl-0 pr-0 col-md-6">
            <img src="<?php echo e(asset('images/Image 04.png')); ?>" class="produk-img">
        </div>
    </div>
    <!-- Education Section        -->

    <section class="services text-center bg-cover bg-center" class="parallax-window" data-parallax="scroll"
        data-image-src="<?php echo e(asset('images/video/Background parallax.png')); ?>" id="about">
        <div class="container">
            <header class="mb-5">
                <p class="font-weight-bold text-uppercase letter-spacing-3 text-chocolate">Galleri</p>
                <h2 class="h3 text-white">Aktifitas Mazta Farma</h2>
            </header>
            <div class="row">
                <div class="top-40 col-lg-3 col-md-6 mb-4 mb-lg-0">
                    <div class="px-4 py-5 text-center contact-item shadow-sm">
                        <img class="contact-item-thumb-img" src="<?php echo e(asset('images/video/01/Image.png')); ?>">
                        <p class="text-small mt-2 mb-0 text-info-services">Pharmacy Con 2018</p>

                    </div>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-lg-0">
                    <div class="px-4 py-5 text-center contact-item shadow-sm">
                        <img class="contact-item-thumb-img" src="<?php echo e(asset('images/video/02/Image.png')); ?>">
                        <p class="text-small mt-2 mb-0 text-info-services">Panti Asuhan 2018</p>

                    </div>
                </div>

                <div class="top-40 col-lg-3 col-md-6 mb-4 mb-lg-0">
                    <div class="px-4 py-5 text-center contact-item shadow-sm">
                        <img class="contact-item-thumb-img" src="<?php echo e(asset('images/video/03/Image.png')); ?>">
                        <p class="text-small mt-2 mb-0 text-info-services">D2 Launching</p>

                    </div>
                </div>

                <div class="col-lg-3 col-md-6 mb-4 mb-lg-0">
                    <div class="px-4 py-5 text-center contact-item shadow-sm">
                        <img class="contact-item-thumb-img" src="<?php echo e(asset('images/video/04/Image.png')); ?>">
                        <p class="text-small mt-2 mb-0 text-info-services">Donasi Antiseptik</p>

                    </div>
                </div>

            </div>
        </div>
    </section>
    <section class="bg-cover bg-center" style="background-image: url('<?php echo e(asset("images/Map Image.png")); ?>'); min-height: 700px;">

        <!-- <div id="map"></div> -->
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBu5nZKbeK-WHQ70oqOWo-_4VmwOwKP9YQ"></script>
<script>
    $(function () {

        function initMap() {

            var location = new google.maps.LatLng(50.0875726, 14.4189987);

            var mapCanvas = document.getElementById('map');
            var mapOptions = {
                center: location,
                zoom: 16,
                panControl: false,
                scrollwheel: false,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            }
            var map = new google.maps.Map(mapCanvas, mapOptions);

            var markerImage = 'marker.png';

            var marker = new google.maps.Marker({
                position: location,
                map: map,
                icon: markerImage
            });

            var contentString = '<div class="info-window">' +
                '<h3>PT MAZTA FARMA</h3>' +
                '<div class="info-content">' +
                '<p>Green Sedayu Biz Park</p>' +
                '<p>DM 16 No.36</p>' +
                '</div>' +
                '</div>';

            var infowindow = new google.maps.InfoWindow({
                content: contentString,
                maxWidth: 400
            });

            marker.addListener('click', function () {
                infowindow.open(map, marker);
            });

            var styles = [{ "featureType": "landscape", "stylers": [{ "saturation": -100 }, { "lightness": 65 }, { "visibility": "on" }] }, { "featureType": "poi", "stylers": [{ "saturation": -100 }, { "lightness": 51 }, { "visibility": "simplified" }] }, { "featureType": "road.highway", "stylers": [{ "saturation": -100 }, { "visibility": "simplified" }] }, { "featureType": "road.arterial", "stylers": [{ "saturation": -100 }, { "lightness": 30 }, { "visibility": "on" }] }, { "featureType": "road.local", "stylers": [{ "saturation": -100 }, { "lightness": 40 }, { "visibility": "on" }] }, { "featureType": "transit", "stylers": [{ "saturation": -100 }, { "visibility": "simplified" }] }, { "featureType": "administrative.province", "stylers": [{ "visibility": "off" }] }, { "featureType": "water", "elementType": "labels", "stylers": [{ "visibility": "on" }, { "lightness": -25 }, { "saturation": -100 }] }, { "featureType": "water", "elementType": "geometry", "stylers": [{ "hue": "#ffff00" }, { "lightness": -25 }, { "saturation": -97 }] }];

            map.set('styles', styles);


        }

        google.maps.event.addDomListener(window, 'load', initMap);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/maztaFarma/resources/views/front/pages/home.blade.php ENDPATH**/ ?>